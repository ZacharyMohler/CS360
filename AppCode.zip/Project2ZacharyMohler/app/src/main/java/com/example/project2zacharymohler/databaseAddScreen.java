package com.example.project2zacharymohler;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class databaseAddScreen extends AppCompatActivity {

    private EditText id_input, name_input, description_input, onhands_input;
    private Button addButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database_add_screen);

        id_input = findViewById(R.id.id_input);
        name_input = findViewById(R.id.name_input);
        description_input = findViewById(R.id.description_input);
        onhands_input = findViewById(R.id.onhands_input);
        addButton = findViewById(R.id.confirmAdd);

        addButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                //initialize the helper and add the elements in the text fields
                //TODO: (if time allows) make it check that the ID doesn't already exist in the db
                DatabaseHelper database = new DatabaseHelper(databaseAddScreen.this);

                database.addItem(Integer.valueOf(id_input.getText().toString().trim()),
                        name_input.getText().toString().trim(),
                        description_input.getText().toString().trim(),
                        Integer.valueOf(onhands_input.getText().toString().trim()));
            }
        });

    }
}