package com.example.project2zacharymohler;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class databaseUpdateScreen extends AppCompatActivity {

    EditText id_input, name_input, description_input, onhands_input;
    Button update_button, delete_button;

    String id, name, description, onhands;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database_update_screen);

        id_input = findViewById(R.id.id_input2);
        name_input = findViewById(R.id.name_input2);
        description_input = findViewById(R.id.description_input2);
        onhands_input = findViewById(R.id.onhands_input2);
        update_button = findViewById(R.id.confirmUpdate);
        delete_button = findViewById(R.id.delete);

        getAndSetIntentData();

        ActionBar ab = getSupportActionBar();
        if(ab != null)
        {
            ab.setTitle(name);
        }

        delete_button.setOnClickListener(new View.OnClickListener()
        {
           @Override
           public void onClick(View view)
           {
                confirmDialog();
           }
        });


        update_button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                DatabaseHelper database = new DatabaseHelper(databaseUpdateScreen.this);

                //preforms a delete of the old element and creates a new one (very similar to add)
                //probably should've called it replace instead of update
                database.updateRow(id);

                database.updateItem(Integer.valueOf(id_input.getText().toString().trim()),
                        name_input.getText().toString().trim(),
                        description_input.getText().toString().trim(),
                        Integer.valueOf(onhands_input.getText().toString().trim()));
            }

        });

    }

    void getAndSetIntentData()
    {
        //while more data exists
        if(getIntent().hasExtra("id") &&
                getIntent().hasExtra("name") &&
                getIntent().hasExtra("description") &&
                getIntent().hasExtra("onhands"))
            {
                //get data from intent
                id = getIntent().getStringExtra("id");
                name = getIntent().getStringExtra("name");
                description = getIntent().getStringExtra("description");
                onhands = getIntent().getStringExtra("onhands");

                //setting intent data
                id_input.setText(id);
                name_input.setText(name);
                description_input.setText(description);
                onhands_input.setText(onhands);

            }
        else
        {
            Toast.makeText(this, "No data", Toast.LENGTH_SHORT).show();
        }

    }

    void confirmDialog()
    {
        //just ensures the user knows what action they're preforming
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete " + name);
        builder.setMessage("are you sure?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                DatabaseHelper helper = new DatabaseHelper(databaseUpdateScreen.this);
                //this can be changed to change the descriptor in the delete dialog
                helper.deleteOneRow(id);
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.create().show();

    }


}