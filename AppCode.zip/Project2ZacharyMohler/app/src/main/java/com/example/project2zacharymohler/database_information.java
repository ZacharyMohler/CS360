package com.example.project2zacharymohler;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class database_information extends AppCompatActivity {

    RecyclerView recyclerView;
    FloatingActionButton addButton;
    Button notificationsButton;

    //database stuff
    DatabaseHelper database;
    ArrayList<String> item_id, item_name, item_description, item_onhands;
    CustomAdapter customAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database_information);

        recyclerView = findViewById(R.id.recyclerView);
        addButton = findViewById(R.id.addButton);
        notificationsButton = findViewById(R.id.notifications);

        //navigates to sms notifications page
        notificationsButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent = new Intent(database_information.this, sms_page.class);
                startActivity(intent);
            }
        });

        //navigates to the database element add screen
        addButton.setOnClickListener(new View.OnClickListener()
        {
           @Override
           public void onClick(View view)
           {
               Intent intent = new Intent(database_information.this, databaseAddScreen.class);
               startActivity(intent);
           }
        });

        //this stuff adds the info from the database to the recycler view
        database = new DatabaseHelper(database_information.this);
        item_id = new ArrayList<>();
        item_name = new ArrayList<>();
        item_description = new ArrayList<>();
        item_onhands = new ArrayList<>();

        storeDataInArrays();

        customAdapter = new CustomAdapter(database_information.this, item_id, item_name, item_description, item_onhands);
        recyclerView.setAdapter(customAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(database_information.this));

    }

    void storeDataInArrays()
    {
        Cursor cursor = database.readAllData();
        //if the database is empty
        if(cursor.getCount() == 0)
        {
            //toast so they know it's not just loading
            Toast.makeText(this, "No data in table", Toast.LENGTH_SHORT).show();
        }
        else
        {
            //otherwise add the database data to our arraylists
            while(cursor.moveToNext())
            {
                item_id.add(cursor.getString(0));
                item_name.add(cursor.getString(1));
                item_description.add(cursor.getString(2));
                item_onhands.add(cursor.getString(3));
            }
        }
    }
}