package com.example.project2zacharymohler;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    Button loginButton, createAccountButton;
    EditText usernameInput, passwordInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.createAccountButton);
        usernameInput = findViewById(R.id.usernameInput);
        passwordInput = findViewById(R.id.passwordInput);

        loginButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                //init helper
                LoginDatabaseHelper helper = new LoginDatabaseHelper(MainActivity.this);

                //get hashmap
                HashMap validValues = helper.readAllData();

                //get data in fields
                String usernameTry = usernameInput.getText().toString().trim();
                String passwordTry = passwordInput.getText().toString().trim();

                //see if they fit a key-value pair from the database of valid logins
                if(validValues.containsKey(usernameTry))
                {
                    if(validValues.get(usernameTry).toString().trim().equals(passwordTry))
                    {
                        Toast.makeText(MainActivity.this, "Successfully logged in", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(MainActivity.this, database_information.class);
                        startActivity(intent);
                    }
                    else //username correct, but password incorrect
                    {
                        Toast.makeText(MainActivity.this, "Incorrect password, try again", Toast.LENGTH_SHORT).show();
                    }
                }
                else //username AND password incorrect
                {
                    Toast.makeText(MainActivity.this, "Username not found, create account", Toast.LENGTH_SHORT).show();
                }
            }
        });

        createAccountButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                String usernameToAdd = usernameInput.getText().toString().trim();
                String passwordToAdd = passwordInput.getText().toString().trim();

                LoginDatabaseHelper helper = new LoginDatabaseHelper(MainActivity.this);

                //add new account to logins database
                helper.addItem(usernameToAdd, passwordToAdd);

            }
        });


    }


}

