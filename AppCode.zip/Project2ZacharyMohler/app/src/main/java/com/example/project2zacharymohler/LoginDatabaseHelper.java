package com.example.project2zacharymohler;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.util.HashMap;

public class LoginDatabaseHelper extends SQLiteOpenHelper
{

    //database info
    private Context context;
    private static final String DATABASE_NAME = "LoginInfo.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_NAME = "logins";
    private static final String COLUMN_USERNAME = "usernames";
    private static final String COLUMN_PASSWORD = "password";

    public LoginDatabaseHelper(@Nullable Context context)
    {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase database)
    {

        //set creation query
        String query = "CREATE TABLE " + TABLE_NAME + " (" + COLUMN_USERNAME + " TEXT, " + COLUMN_PASSWORD + " TEXT);";
        //call query in database
        database.execSQL(query);

    }

    @Override
    public void onUpgrade(SQLiteDatabase database, int i, int i1)
    {
        database.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(database);
    }

    //adds new login information
    void addItem(String username, String password)
    {
        //database setup stuff
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        //TODO: (if time allows) check a created username doesn't already exist
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);

        long result = database.insert(TABLE_NAME, null, values);

        if(result == -1)
        {
            Toast.makeText(context, "Couldn't create account", Toast.LENGTH_SHORT).show();
        }
        else
        {
            Toast.makeText(context, "Created Account for " + username, Toast.LENGTH_SHORT).show();
        }
    }

    //returns all usernames and passwords in a hashmap
    public HashMap<String, String> readAllData()
    {
        //initialize hashmap
        HashMap<String, String> values = new HashMap<>();

        //get all from the login info table
        String query = "SELECT * FROM " + TABLE_NAME;
        SQLiteDatabase database = this.getReadableDatabase();

        //init cursor to add items to the hashmap
        Cursor cursor = database.rawQuery(query, null);

        //move to first returns a bool depending on if there is a first element (not empty)
        if(cursor.moveToFirst())
        {
            do
            {
                //add usernames and passwords as a key value pair to the hashmap
                String username = cursor.getString(0);
                String password = cursor.getString(1);
                values.put(username, password);
            }
            while (cursor.moveToNext());

        }
        else
        {

        }
        return values;
    }
}
