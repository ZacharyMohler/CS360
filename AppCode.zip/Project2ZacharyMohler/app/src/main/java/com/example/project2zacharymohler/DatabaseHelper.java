package com.example.project2zacharymohler;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper
{
    //database info
    private Context context;
    private static final String DATABASE_NAME = "ItemInfo.db";
    private static final int DATABASE_VERSION = 1;
    //database element info
    private static final String TABLE_NAME = "items";
    private static final String COLUMN_ITEM_NAME = "item_name";
    private static final String COLUMN_ITEM_ID = "item_id";
    private static final String COLUMN_ITEM_DESCRIPTION = "item_description";
    private static final String COLUMN_ITEM_ONHANDS = "item_onhands";


    DatabaseHelper(@Nullable Context context)
    {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase database)
    {
        //set creation query
        String query = "CREATE TABLE " + TABLE_NAME + " (" + COLUMN_ITEM_ID + " INTEGER, " + COLUMN_ITEM_NAME + " TEXT, " + COLUMN_ITEM_DESCRIPTION + " TEXT, " + COLUMN_ITEM_ONHANDS + " INTEGER);";
        //call query in database
        database.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase database, int i, int i1)
    {
        //basically updates the table
        database.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(database);
    }

    void addItem(int id, String name, String description, int onhands)
    {
        //init db stuff
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        //add the data to the corresponding column in the table
        values.put(COLUMN_ITEM_ID, id);
        values.put(COLUMN_ITEM_NAME, name);
        values.put(COLUMN_ITEM_DESCRIPTION, description);
        values.put(COLUMN_ITEM_ONHANDS, onhands);

        //this just checks that things worked
        long result = database.insert(TABLE_NAME, null, values);

        //-1 means it couldn't do the action
        if(result == -1)
        {
            Toast.makeText(context, "Failed to add!", Toast.LENGTH_SHORT).show();
        }
        else
        {
            Toast.makeText(context, "Added " + name + " to database.", Toast.LENGTH_SHORT).show();
        }

    }

    void updateItem(int id, String name, String description, int onhands)
    {
        //this is identical to the add but changes the toast
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_ITEM_ID, id);
        values.put(COLUMN_ITEM_NAME, name);
        values.put(COLUMN_ITEM_DESCRIPTION, description);
        values.put(COLUMN_ITEM_ONHANDS, onhands);

        long result = database.insert(TABLE_NAME, null, values);

        if(result == -1)
        {
            Toast.makeText(context, "Couldn't add new data", Toast.LENGTH_SHORT).show();
        }
        else
        {

        }

    }

    //returns a database cursor to traverse the data
    Cursor readAllData()
    {
        String query = "SELECT * FROM " + TABLE_NAME;
        SQLiteDatabase database = this.getReadableDatabase();

        Cursor cursor = null;
        if(database != null)
        {
            cursor = database.rawQuery(query, null);
        }
        return cursor;
    }


    void deleteOneRow(String row_id)
    {
        SQLiteDatabase database = this.getWritableDatabase();
        //find entry with id equal to row_id and delete that thang!
        long result = database.delete(TABLE_NAME, "item_id=?", new String[]{row_id});

        //-1 just means it couldn't preform the delete for whatever reason
        if(result == -1)
        {
            Toast.makeText(context, "Couldn't Delete", Toast.LENGTH_SHORT).show();
        }
        else
        {
            Toast.makeText(context, "Deleted", Toast.LENGTH_SHORT).show();
        }

    }

    //identical to delete but changed for update so it sends different toast messages
    void updateRow(String row_id)
    {
        SQLiteDatabase database = this.getWritableDatabase();
        long result = database.delete(TABLE_NAME, "item_id=?", new String[]{row_id});

        if(result == -1)
        {
            Toast.makeText(context, "Couldn't remove old data", Toast.LENGTH_SHORT).show();
        }
        else
        {
            Toast.makeText(context, "Updated", Toast.LENGTH_SHORT).show();
        }

    }



}
